import { expect, test, type APIRequestContext, type Page } from "@playwright/test"

const externalCinemaURL = process.env.CINEMA_E2E_URL
const managedAgentPort = process.env.CINEMA_E2E_AGENT_PORT || "4187"
const agentBaseURL = `http://127.0.0.1:${managedAgentPort}`

type FixtureProject = {
  projectID: string
  cinemaURL: string
}

async function readFixtureProject(request: APIRequestContext): Promise<FixtureProject> {
  const response = await request.get(`${agentBaseURL}/e2e/project`)
  expect(response.ok()).toBe(true)
  const envelope = await response.json() as { success: boolean; data?: FixtureProject }
  expect(envelope.success).toBe(true)
  expect(envelope.data?.projectID).toBeTruthy()
  expect(envelope.data?.cinemaURL).toBeTruthy()
  return envelope.data!
}

async function openManagedProject(page: Page, request: APIRequestContext) {
  const project = await readFixtureProject(request)
  const reset = await request.post(`${agentBaseURL}/e2e/reset`)
  expect(reset.ok()).toBe(true)
  const initialEvents = page.waitForResponse((response) => response.url().includes("/events?limit=1"))
  await page.goto(project.cinemaURL)
  await initialEvents
  await expect(page.locator(".cinema-save-status")).toHaveClass(/is-saved/)
  return project
}

async function editStoryBrief(page: Page, value: string) {
  const textNode = page.locator('.react-flow__node-cinemaNode[data-id="story-brief"]')
  await textNode.locator(".cinema-text-card-preview-text").dblclick()
  const editor = textNode.locator("textarea.cinema-text-card-editor")
  await editor.fill(value)
  return editor
}

async function startTextGeneration(page: Page, nodeID: string, prompt: string) {
  const textNode = page.locator(`.react-flow__node-cinemaNode[data-id="${nodeID}"]`)
  await textNode.click()
  await page.locator("textarea.cinema-text-card-generator-input").fill(prompt)
  await page.locator("button.cinema-text-card-submit").click()
  return textNode
}

test.describe("Cinema save reliability", () => {
  test.skip(Boolean(externalCinemaURL), "Reliability fault injection uses the isolated managed Agent fixture.")

  test("offers exactly the four core canvas node types", async ({ page, request }) => {
    await openManagedProject(page, request)
    await page.locator(".react-flow__pane").click({ button: "right", position: { x: 180, y: 160 } })
    await expect(page.getByRole("menuitem")).toHaveText([
      "Add Text",
      "Add Image",
      "Add Video",
      "Add Audio",
    ])
  })

  test("opens the composer on selection and keeps the text preview draggable until double-click edit", async ({ page, request }) => {
    await openManagedProject(page, request)
    const textNode = page.locator('.react-flow__node-cinemaNode[data-id="story-brief"]')
    const preview = textNode.locator(".cinema-text-card-preview-text")
    const composer = page.locator(".cinema-text-card-generator")

    await expect(composer).toBeHidden()
    await preview.click()
    await expect(composer).toBeVisible()
    await expect(textNode.locator("textarea.cinema-text-card-editor")).toHaveCount(0)

    const before = await textNode.boundingBox()
    const previewBox = await preview.boundingBox()
    expect(before).not.toBeNull()
    expect(previewBox).not.toBeNull()
    await page.mouse.move(previewBox!.x + previewBox!.width / 2, previewBox!.y + previewBox!.height / 2)
    await page.mouse.down()
    await page.mouse.move(previewBox!.x + previewBox!.width / 2 + 80, previewBox!.y + previewBox!.height / 2 + 32, { steps: 8 })
    await page.mouse.up()
    const after = await textNode.boundingBox()
    expect(after).not.toBeNull()
    expect(after!.x - before!.x).toBeGreaterThan(60)
    expect(after!.y - before!.y).toBeGreaterThan(20)

    await preview.dblclick()
    await expect(textNode.locator("textarea.cinema-text-card-editor")).toBeFocused()
  })

  test("renders Markdown for reading and preserves its source when editing", async ({ page, request }) => {
    await openManagedProject(page, request)
    const markdown = "**分镜脚本**\n\n---\n\n## 镜头 1\n第一行\n第二行"
    const editor = await editStoryBrief(page, markdown)
    await editor.press("Escape")
    await expect(page.locator(".cinema-save-status")).toHaveClass(/is-saved/)

    const textNode = page.locator('.react-flow__node-cinemaNode[data-id="story-brief"]')
    const preview = textNode.locator(".cinema-text-card-preview-text")
    await expect(preview.locator("strong")).toHaveText("分镜脚本")
    await expect(preview.getByRole("heading", { name: "镜头 1" })).toBeVisible()
    await expect(preview.locator("hr")).toHaveCount(1)
    await expect(preview.locator("br")).toHaveCount(1)
    await expect(preview).not.toContainText("**")

    await preview.dblclick()
    const reopenedEditor = textNode.locator("textarea.cinema-text-card-editor")
    await expect(reopenedEditor).toHaveValue(markdown)

    const longMarkdown = `## 长内容\n${Array.from({ length: 18 }, (_, index) => `镜头 ${index + 1}`).join("\n")}\n\n\`${"x".repeat(240)}\``
    await reopenedEditor.fill(longMarkdown)
    await reopenedEditor.press("Escape")
    await expect(page.locator(".cinema-save-status")).toHaveClass(/is-saved/)
    const previewMetrics = await preview.evaluate((element) => ({
      clientHeight: element.clientHeight,
      clientWidth: element.clientWidth,
      scrollHeight: element.scrollHeight,
      scrollWidth: element.scrollWidth,
    }))
    expect(previewMetrics.scrollHeight).toBeGreaterThan(previewMetrics.clientHeight)
    expect(previewMetrics.scrollWidth).toBeLessThanOrEqual(previewMetrics.clientWidth + 1)
  })

  test("keeps an offline edit visible and persists it after manual retry", async ({ page, request }) => {
    const project = await openManagedProject(page, request)
    let offline = true
    let commandAttempts = 0
    await page.route(/\/api\/cinema\/projects\/[^/]+\/commands$/, async (route) => {
      commandAttempts += 1
      if (offline) {
        await route.abort("internetdisconnected")
        return
      }
      await route.continue()
    })

    const editor = await editStoryBrief(page, "Draft retained while offline.")
    await expect(page.locator(".cinema-save-status")).toContainText("保存失败", { timeout: 8_000 })
    expect(commandAttempts).toBe(3)
    await expect(editor).toHaveValue("Draft retained while offline.")

    offline = false
    await page.getByRole("button", { name: "重试保存" }).click()
    await expect(page.locator(".cinema-save-status")).toContainText("已保存")

    const canvasResponse = await request.get(
      `${agentBaseURL}/api/cinema/projects/${encodeURIComponent(project.projectID)}/canvas`,
    )
    const canvasEnvelope = await canvasResponse.json() as {
      data?: { nodes?: Array<{ id: string; data?: { text?: string } }> }
    }
    expect(canvasEnvelope.data?.nodes?.find((node) => node.id === "story-brief")?.data?.text)
      .toBe("Draft retained while offline.")
  })

  test("rebases a stale command without changing its id", async ({ page, request }) => {
    const project = await openManagedProject(page, request)
    const observedCommands: Array<{ id: string; baseRevision: number }> = []
    await page.route(/\/api\/cinema\/projects\/[^/]+\/commands$/, async (route) => {
      const body = route.request().postDataJSON() as { id: string; baseRevision: number }
      observedCommands.push({ id: body.id, baseRevision: body.baseRevision })
      await route.continue()
    })

    const externalUpdate = await request.post(
      `${agentBaseURL}/api/cinema/projects/${encodeURIComponent(project.projectID)}/commands`,
      {
        data: {
          id: "external-revision-update",
          type: "update-viewport",
          actor: "e2e-external-writer",
          baseRevision: 0,
          viewport: { x: 40, y: 24, zoom: 0.9 },
        },
      },
    )
    expect(externalUpdate.ok()).toBe(true)

    await editStoryBrief(page, "Rebased after an external update.")
    await expect(page.locator(".cinema-save-status")).toContainText("已保存")
    await expect.poll(() => observedCommands.length).toBeGreaterThanOrEqual(2)
    expect(observedCommands[0]?.baseRevision).toBe(0)
    expect(observedCommands[1]?.baseRevision).toBe(1)
    expect(observedCommands[1]?.id).toBe(observedCommands[0]?.id)
  })

  test("prevents silent navigation while a failed command remains queued", async ({ page, request }) => {
    await openManagedProject(page, request)
    await page.route(/\/api\/cinema\/projects\/[^/]+\/commands$/, (route) => route.abort("internetdisconnected"))
    const editor = await editStoryBrief(page, "Unsaved navigation guard.")
    await expect(page.locator(".cinema-save-status")).toContainText("保存失败", { timeout: 8_000 })

    const beforeUnload = await page.evaluate(() => {
      const event = new Event("beforeunload", { cancelable: true }) as BeforeUnloadEvent
      window.dispatchEvent(event)
      return { defaultPrevented: event.defaultPrevented, returnValue: event.returnValue }
    })
    expect(beforeUnload.defaultPrevented).toBe(true)
    expect(beforeUnload.returnValue).toBe(false)
    await expect(editor).toHaveValue("Unsaved navigation guard.")
  })

  test("keeps concurrent text generation busy and error state isolated by node", async ({ page, request }) => {
    const model = {
      value: "e2e/mock-text",
      providerID: "e2e",
      modelID: "mock-text",
      label: "E2E Mock Text",
      providerLabel: "E2E",
      available: true,
      supportsImageInput: false,
    }
    await page.route(/\/api\/cinema\/projects\/[^/]+\/text-models$/, (route) => route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({
        success: true,
        data: { items: [model], selection: { model: model.value }, effectiveModel: model },
      }),
    }))

    const releaseFailures = new Map<string, (message: string) => void>()
    await page.route(/\/api\/cinema\/projects\/[^/]+\/text-generations$/, async (route) => {
      const body = route.request().postDataJSON() as { nodeID: string }
      const message = await new Promise<string>((resolve) => {
        releaseFailures.set(body.nodeID, resolve)
      })
      releaseFailures.delete(body.nodeID)
      await route.fulfill({
        status: 503,
        contentType: "application/json",
        body: JSON.stringify({
          success: false,
          error: { code: "E2E_PROVIDER_FAILURE", message },
        }),
      })
    })

    await openManagedProject(page, request)
    const storyBrief = await startTextGeneration(page, "story-brief", "Expand the first brief.")
    await expect.poll(() => releaseFailures.has("story-brief")).toBe(true)
    const secondBrief = await startTextGeneration(page, "second-brief", "Expand the second brief.")
    await expect.poll(() => releaseFailures.has("second-brief")).toBe(true)

    await expect(storyBrief.locator(".cinema-node-status-dot.is-generating")).toBeVisible()
    await expect(secondBrief.locator(".cinema-node-status-dot.is-generating")).toBeVisible()

    releaseFailures.get("story-brief")?.("First provider failed")
    await expect(storyBrief.locator(".cinema-node-status-dot.is-failed")).toBeVisible()
    await expect(secondBrief.locator(".cinema-node-status-dot.is-generating")).toBeVisible()

    releaseFailures.get("second-brief")?.("Second provider failed")
    await expect(secondBrief.locator(".cinema-node-status-dot.is-failed")).toBeVisible()

    await storyBrief.click()
    await expect(page.getByRole("alert")).toContainText("First provider failed")
    await secondBrief.click()
    await expect(page.getByRole("alert")).toContainText("Second provider failed")
  })

  test("keeps the text generation prompt focused while autosave snapshots return", async ({ page, request }) => {
    const model = {
      value: "e2e/mock-text",
      providerID: "e2e",
      modelID: "mock-text",
      label: "E2E Mock Text",
      providerLabel: "E2E",
      available: true,
      supportsImageInput: false,
    }
    await page.route(/\/api\/cinema\/projects\/[^/]+\/text-models$/, (route) => route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({
        success: true,
        data: { items: [model], selection: { model: model.value }, effectiveModel: model },
      }),
    }))
    await page.route(/\/api\/cinema\/projects\/[^/]+\/commands$/, async (route) => {
      await new Promise((resolve) => setTimeout(resolve, 450))
      await route.continue()
    })

    await openManagedProject(page, request)
    const textNode = page.locator('.react-flow__node-cinemaNode[data-id="story-brief"]')
    await textNode.click()
    const prompt = page.locator("textarea.cinema-text-card-generator-input")
    await prompt.fill("描述一望无际的草原")
    await expect(page.locator(".cinema-save-status")).toHaveClass(/is-saving/)
    await expect(prompt).toBeFocused()
    await prompt.press("End")
    await prompt.type("，远处有缓慢移动的云影")
    await expect(prompt).toHaveValue("描述一望无际的草原，远处有缓慢移动的云影")
    await expect(page.locator(".cinema-save-status")).toContainText("已保存")
    await expect(prompt).toBeFocused()
    await expect(prompt).toHaveValue("描述一望无际的草原，远处有缓慢移动的云影")
  })

  test("keeps the video prompt focused while autosave snapshots return", async ({ page, request }) => {
    await openManagedProject(page, request)
    await page.route(/\/api\/cinema\/projects\/[^/]+\/commands$/, async (route) => {
      await new Promise((resolve) => setTimeout(resolve, 450))
      await route.continue()
    })

    await page.locator(".react-flow__pane").click({ button: "right", position: { x: 180, y: 160 } })
    await page.getByRole("menuitem", { name: "Add Video" }).click()
    const prompt = page.locator("textarea.cinema-video-prompt-input").last()
    await expect(prompt).toBeVisible()

    await prompt.fill("将第一张图变成缓慢推进的电影镜头")
    await expect(page.locator(".cinema-save-status")).toHaveClass(/is-saving/)
    await expect(prompt).toBeFocused()
    await prompt.press("End")
    await prompt.type("，保留人物面部细节")
    await expect(prompt).toHaveValue("将第一张图变成缓慢推进的电影镜头，保留人物面部细节")
    await expect(page.locator(".cinema-save-status")).toContainText("已保存")
    await expect(prompt).toBeFocused()
    await expect(prompt).toHaveValue("将第一张图变成缓慢推进的电影镜头，保留人物面部细节")
  })

  test("replaces generated text and restores the previous draft from the undo toast", async ({ page, request }) => {
    const model = {
      value: "e2e/mock-text",
      providerID: "e2e",
      modelID: "mock-text",
      label: "E2E Mock Text",
      providerLabel: "E2E",
      available: true,
      supportsImageInput: false,
    }
    await page.route(/\/api\/cinema\/projects\/[^/]+\/text-models$/, (route) => route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({
        success: true,
        data: { items: [model], selection: { model: model.value }, effectiveModel: model },
      }),
    }))
    await page.route(/\/api\/cinema\/projects\/[^/]+\/text-generations$/, async (route) => {
      const body = route.request().postDataJSON() as { nodeID: string }
      const canvasResponse = await request.get(route.request().url().replace(/\/text-generations$/, "/canvas"))
      const canvasEnvelope = await canvasResponse.json() as { data: { nodes: Array<{ id: string; data?: Record<string, unknown> }> } }
      const generatedText = "**Generated replacement.**"
      const canvas = {
        ...canvasEnvelope.data,
        nodes: canvasEnvelope.data.nodes.map((node) => node.id === body.nodeID
          ? { ...node, data: { ...node.data, text: `A test story brief.\n\n${generatedText}`, generationPrompt: "" } }
          : node),
      }
      await route.fulfill({
        status: 200,
        contentType: "application/json",
        body: JSON.stringify({
          success: true,
          data: { canvas, nodeID: body.nodeID, text: `A test story brief.\n\n${generatedText}`, generatedText, model: model.value },
        }),
      })
    })

    await openManagedProject(page, request)
    const storyBrief = await startTextGeneration(page, "story-brief", "Replace the brief.")
    await expect(storyBrief.locator(".cinema-text-card-preview-text")).toHaveText("Generated replacement.")
    await expect(storyBrief.locator(".cinema-text-card-preview-text strong")).toHaveText("Generated replacement.")
    const undo = page.getByRole("button", { name: /Undo|撤销/ })
    await expect(undo).toBeVisible()
    await undo.click()
    await expect(storyBrief.locator(".cinema-text-card-preview-text")).toHaveText("A test story brief.")
    await expect(page.locator(".cinema-save-status")).toHaveClass(/is-saved/)
  })
})
